# Distance Calculator
## Introduction
The distance calculator is a way to find the distance between two points!
## Usage
First, you will need to create four variables, `p1x`, `p2x`, `p1y`, and `p2y`.
Next, you will need to assign them to coordinates. It will look like this:
````python
#The coordinates shown here are just an example.
import distancecalc
p1x = 4
p2x = 3
p1y = 5
p2y = 6
````
After you have done this, you can calculate the distance by simply running `print(distancecalc.distance(p1x, p1y, p2x, p2y))
`.(Obviously you don't have to print it, you can save as variable.)