# Distance Calculator
## Introduction
The distance calculator is a way to find the distance between two points!
## Usage
First, you will need to create two variables, `p1`, and `p2`.
Next, you will need to assign them to the point class, with the coordinates after that. It will look like this:
````python
#The coordinates shown here are just an example.
p1 = Point(4, 9)
p2 = Point(3, 4)
````
After you have done this,  you can calculate the distance by simply running `print(p1.distance(p2))
`.(Obviously you don't have to print it, you can save as variable.)